// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init()
const db = cloud.database()
// 云函数入口函数
const _ = db.command
exports.main = async (event, context) => {

  console.log('传入云函数' + event)
  return await db.collection('topic').doc(event.id).update({
    // data 传入需要局部更新的数据      
    data: {
      viewnum: _.inc(1)
    }
  })
}