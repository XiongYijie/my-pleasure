// miniprogram/pages/home/home.js
Page({

  /**
   * 页面的初始数据
   */
 
  data: {
    
    page: 0,
    pageSize: 20,
    totalCount: 0,
    topics: {},
    hasNextPage: !0,
    scrollTop: 0,
    activename: '全部',
    statusBarHeight: getApp().globalData.statusBarHeight,
    searchValue:'',
    category: [{
      name: "助力",
      type: "hotTopic"
    }, {
      name: "捞人",
      type: "category"
    }, {
      name: "脑洞",
      type: "category"
    }, {
      name: "外快",
      type: "category"
    }, {
      name: "曝光",
      type: "category"
    }],
  },
  getsearchValue:function(e){
    this.setData({searchValue: e.detail});
    console.log(this.data.searchValue);
    this.getData(this.data.page);
  },
  switchCategory: function (t) {
    var a = this, e = t.target.dataset, o = e.name;
    this.setData({ activename: o });

  },
  switchCategory2: function (t) {
    var a = t.target.dataset.name;
    this.setData({ activename: a });
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    console.log('onload');
    this.getOpenid();
  },
  getOpenid() {
    console.log("获取")
    let that = this;
    wx.cloud.callFunction({
      name: 'login',
      complete: res => {
        console.log('云函数获取到的openid: ', res.result.openid)
        that.setData({
          user_openid: res.result.openid
        })
        that.data.user_openid = res.result.openid
        console.log('获取到的openid: ', that.data.user_openid)
        this.getData(this.data.page);
      }
    })
  },
  /**
   * 获取列表数据
   *
   */
  getData: function(page) {
    var that = this;
    console.log("page--->" + page);
    const db = wx.cloud.database();
    // 获取总数
    db.collection('topic').count({
      success: function(res) {
        that.data.totalCount = res.total;
      }
    })
    // 获取前十条
    try {
      db.collection('topic')
        .where({
          //使用正则查询，实现对搜索的模糊查询
          content: db.RegExp({
            regexp: that.data.searchValue,
            //从搜索栏中获取的value作为规则进行匹配。
            options: 'i',
            //大小写不区分
          })
          })
        .limit(that.data.pageSize) // 限制返回数量为 20 条
        .orderBy('commentnum', 'desc')
        .get({
          success: function(res) {
            // res.data 是包含以上定义的两条记录的数组
            // console.log(res.data)
            for(var a=0;a<res.data.length;a++){
              var date = res.data[a].date;
              res.data[a].date = date.getFullYear() + '-' + (date.getMonth() + 1) + '-' + date.getDate() + "  " + date.getHours() + ':' + date.getMinutes() + ':' + date.getSeconds();
            }
            that.data.topics = res.data;
            that.setData({
              topics: that.data.topics,
            })
            wx.hideNaviationBarLoading();//隐藏加载
            wx.stopPullDownRefresh();

          },
          fail: function(event) {
            wx.hideNavigationBarLoading();//隐藏加载
            wx.stopPullDownRefresh();
            console.log("======" + event);
          }
        })
    } catch (e) {
      wx.hideNavigationBarLoading();//隐藏加载
      wx.stopPullDownRefresh();
      console.error(e);
    }
  },
  /**
   * item 点击
   */
  onItemClick: function (event) {
    var id = event.currentTarget.dataset.topicid;
    console.log(id);
    wx.cloud.callFunction({
      // 云函数名称      
      name: 'addview',
      // 传给云函数的参数      
      data: {
        id: id
      },
      success: function (res) {
        console.log('成功调用云函数' + id)
      },
      fail: console.error
    })
    wx.navigateTo({
      url: "../homeDetail/homeDetail?id=" + id
    })
  },
  remove: function (event) {
    var that = this
    wx.showModal({
      title: '提示',
      content: '确定要删除吗？',
      success: function (sm) {
        if (sm.confirm) {
          wx.showToast({
            title: '成功删除'
          })
          var id = event.currentTarget.dataset.topicid;
          console.log("删除" + id)
          wx.cloud.callFunction({
            name: 'remove',
            data: {
              id: id
            },
            complete: res => {
              that.getData(that.data.page);
            }
          })
        } else if (sm.cancel) {
          console.log('用户点击取消')
        }
      }
    })

  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {
    console.log('onReady');
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    console.log('onShow');
    console.log('onShow');
    this.getData(this.data.page);
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {
    console.log('onhide');
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {
console.log('onUnload');
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {
    wx.showNavigationBarLoading() //在标题栏中显示加载
console.log('pulldown');
    this.getData(this.data.page);
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {
    var that = this;
    var temp = [];
    // 获取后面十条
    console.log("length---->" + this.data.topics.length);
    console.log("count--->" + this.data.totalCount);
    if(this.data.topics.length < this.data.totalCount){
      try {
        const db = wx.cloud.database();
        db.collection('topic')
          .where({
            //使用正则查询，实现对搜索的模糊查询
            content: db.RegExp({
              regexp: that.data.searchValue,
              //从搜索栏中获取的value作为规则进行匹配。
              options: 'i',
              //大小写不区分
            })
          })
          .skip(5)
          .limit(that.data.pageSize) // 限制返回数量为 10 条
          .orderBy('date', 'desc')
          .get({
            success: function (res) {
              // res.data 是包含以上定义的两条记录的数组
              for (var a = 0; a < res.data.length; a++) {
                var date = res.data[a].date;
                res.data[a].date = date.getFullYear() + '-' + (date.getMonth() + 1) + '-' + date.getDate() + "  " + date.getHours() + ':' + date.getMinutes() + ':' + date.getSeconds();
              }
              if (res.data.length > 0) {
                for(var i=0; i < res.data.length; i++){
                  var tempTopic = res.data[i];
                  console.log(tempTopic);
                  temp.push(tempTopic);
                }

                var totalTopic = {};
                totalTopic =  that.data.topics.concat(temp);

                console.log(totalTopic);
                that.setData({
                  topics: totalTopic,
                })
              } else {
                wx.showToast({
                  title: '没有更多数据了',
                })
              }


            },
            fail: function (event) {
              console.log("======" + event);
            }
          })
      } catch (e) {
        console.error(e);
      }
    }else{
      wx.showToast({
        title: '没有更多数据了',
      })
    }

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})