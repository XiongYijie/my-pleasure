// miniprogram/pages/homeDetail/homeDetail.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    statusBarHeight: getApp().globalData.statusBarHeight,
    canIUse: wx.canIUse('button.open-type.getUserInfo'),
    cn: 0,
    liuyantext: '',
    topic: {},
    liuyanlist: {},
    user: {},
    id: '',
    isLike: false,
    chooseSize: false,
    replyid:'',
    replyshow:'说点什么吧：',
    animationData: {}
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    this.jugdeUserLogin();
    var mid = options.id;
    that.data.id = mid;
    this.getdata();

  },
  getdata: function () {

    var that = this;
    const db = wx.cloud.database();
    db.collection('topic').doc(that.data.id).get({
      success: function (res) {
        // res.data 包含该记录的数据

        var date = res.data.date;
        res.data.date = date.getFullYear() + '-' + (date.getMonth() + 1) + '-' + date.getDate() + "  " + date.getHours() + ':' + date.getMinutes() + ':' + date.getSeconds();

        that.topic = res.data;
        console.log(that.topic.isLike)
        that.setData({
          topic: that.topic,
          isLike: that.topic.isLike,
        })
      }
    })

    // 下面是获取评论
    const db2 = wx.cloud.database();
    db2.collection('cm').where({ topicid: that.data.id }).get({
      success: function (res2) {
        // res.data 包含该记录的数据
        for (var a = 0; a < res2.data.length; a++) {
          var date = res2.data[a].date;
          res2.data[a].date = date.getFullYear() + '-' + (date.getMonth() + 1) + '-' + date.getDate() + "  " + date.getHours() + ':' + date.getMinutes() + ':' + date.getSeconds();
        }
        that.data.liuyanlist = res2.data;
        that.setData({
          liuyanlist: that.data.liuyanlist,
          cn: that.data.liuyanlist.length
        })
        console.log(that.data.liuyanlist.length)

      }
    })


  },
  
  // 预览图片
  previewImg: function (e) {
    //获取当前图片的下标
    var index = e.currentTarget.dataset.index;

    wx.previewImage({
      //当前显示图片
      current: this.data.topic.images[index],
      //所有图片
      urls: this.data.topic.images
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () { },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () { },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () { },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () { },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    wx.showNavigationBarLoading() //在标题栏中显示加载
    console.log('pulldown');
    this.getdata();
    //隐藏导航栏加载框
    wx.hideNavigationBarLoading();
    // 停止下拉动作
    wx.stopPullDownRefresh();
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
 

  // 留言
  formSubmit: function (e) {
     

    if (this.data.canIUse) {
    
      this.jugdeUserLogin();
      this.setData({
        chooseSize:false
      })
      wx.showToast({
        title: '金币+1',
        icon: 'success'
      })
      this.data.liuyantext = e.detail.value.liuyantext; //获取表单所有name=liuyantext的值
      this.countcoin();
      if (this.data.liuyantext.length > 0 && this.data.user!=null) {
        
        
        this.saveDataToServer();
        
        for (var i = 0; i < 10000; i++) {
          for (var j = 0; j < 10000; j++){
          if (i == 9999&&j==9999)
            this.getdata();
          }
        }
        
        console.log(this.data.liuyantext);
        console.log(this.data.user);
        
        
        
      } else {
        wx.showToast({
          title: '没有内容不能发布哦',
        })
      }

    } else {
      this.jugdeUserLogin();
    }
  },
  jugdeUserLogin: function (event) {
    var that = this;
    // 查看是否授权
    wx.getSetting({
      success(res) {
        if (res.authSetting['scope.userInfo']) {
          // 已经授权，可以直接调用 getUserInfo 获取头像昵称
          wx.getUserInfo({
            success: function (res) {

              that.data.user = res.userInfo;
              console.log(that.data.user)
            }
          })
        }
      }
    })
  },
  countcoin: function () {

    var that = this;
    wx.cloud.callFunction({
      name: 'login',
      complete: res => {
        console.log('云函数获取到的openid: ', res.result.openid)
        var oi = res.result.openid
        var coin = 0
        wx.cloud.callFunction({
          // 云函数名称      
          name: 'count',
          // 传给云函数的参数      
          data: {
            oi: oi
          },
          success: function (res) {
            console.log('成功调用云函数' + res.result.total)
            var ct = res.result.total
            if (ct > 0) {
              const db2 = wx.cloud.database();
              db2.collection('userscoin')
                .where({
                  _openid: oi
                })
                .limit(1)
                .get({
                  success: function (res) {
                    coin = res.data[0].coin
                    console.log("已有" + res.data[0].coin)
                    wx.cloud.callFunction({
                      // 云函数名称      
                      name: 'fixcoin',
                      // 传给云函数的参数      
                      data: {
                        oi: oi,
                        coin: coin,
                        c: 1
                      },
                      success: function (res) {
                        console.log("传入" + oi + coin)
                      }
                    })
                  }
                })
              console.log('修改')
            }
            else {
              const db2 = wx.cloud.database();
              db2.collection('userscoin').add({
                data: { coin: 10+1 },

              }),
                console.log("新建user")
            }
          },
          fail: console.error
        })
      }
    })
  },
  saveDataToServer: function (event) {
    var that = this;
    var ex='';
    if (this.data.replyshow !='说点什么吧：'){
      ex=this.data.replyshow
    }
    const db = wx.cloud.database();
    const cm = db.collection('cm')
    db.collection('cm').add({
      // data 字段表示需新增的 JSON 数据
      data: {
        comment: ex+that.data.liuyantext,
        date: new Date(),
        user: that.data.user,
        topicid: that.data.id,
        replyid: that.data.replyid,
        
        read:false
      },
      success: function (res) {
        // res 是一个对象，其中有 _id 字段标记刚创建的记录的 id
        // 清空，然后重定向到首页
        console.log("success---->" + res)

        // 清空数据
        that.data.liuyantext = "";

        that.setData({
          liuyantext: '',
        })
      },
      complete: function (res) {

        console.log("complete---->" + res);
      }
    })

    // const db2 = wx.cloud.database()
    // const topic = db2.collection('topic')
    // db2.collection('topic')
    //   .doc(that.data.id)
    //   .update({
    //     data: {
    //       commentnum: that.data.cn + 1
    //     },
    //     success: res => {
    //       console.log('已有评论数' + that.data.cn)
    //       console.log('id' + that.data.id)
    //       that.setData({ cn: 0 })
    //       console.log('[数据库] [更新记录] 成功：')
    //     },
    //     fail: err => {
    //       console.error('[数据库] [更新记录] 失败：', err)
    //     }
    //   })
    wx.cloud.callFunction({      
      // 云函数名称      
      name: 'update',      
      // 传给云函数的参数      
      data: {        
        id: that.data.id,
        cn: that.data.cn     
      },      
      success: function (res) {        
        console.log('成功调用云函数'+res)      
      },      
        fail: console.error    
    })


  },
  chooseSezi: function (e) {
    if (e.currentTarget.dataset['c']!='1'){
      this.setData({
        replyshow:'回复'+e.currentTarget.dataset['name']+':'
      })
      this.setData({
        replyid:e.currentTarget.dataset['replyid']
      })
      console.log("回复id:" + this.data.replyid)
    }
    else{
      this.setData({
        replyshow: '说点什么吧：'
      })
      this.setData({
        replyid: this.data.topic._openid
      })
    }
    
    // 用that取代this，防止不必要的情况发生
    var that = this;
    // 创建一个动画实例
    var animation = wx.createAnimation({
      // 动画持续时间
      duration: 500,
      // 定义动画效果，当前是匀速
      timingFunction: 'linear'
    })
    // 将该变量赋值给当前动画
    that.animation = animation
    // 先在y轴偏移，然后用step()完成一个动画
    animation.translateY(200).step()
    // 用setData改变当前动画
    that.setData({
      // 通过export()方法导出数据
      animationData: animation.export(),
      // 改变view里面的Wx：if
      chooseSize: true
    })
    // 设置setTimeout来改变y轴偏移量，实现有感觉的滑动
    setTimeout(function () {
      animation.translateY(0).step()
      that.setData({
        animationData: animation.export()
      })
    }, 200)
  },
  hideModal: function (e) {
    var that = this;
    var animation = wx.createAnimation({
      duration: 500,
      timingFunction: 'linear'
    })
    that.animation = animation
    animation.translateY(200).step()
    that.setData({
      animationData: animation.export()

    })
    setTimeout(function () {
      animation.translateY(0).step()
      that.setData({
        animationData: animation.export(),
        chooseSize: false
      })
    }, 200)
  }
})