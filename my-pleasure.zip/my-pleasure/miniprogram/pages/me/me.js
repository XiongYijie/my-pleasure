// miniprogram/pages/me/me.js
var app = getApp();
Page({

  actioncnt: function() {        
    wx.showActionSheet({            
      itemList:  ['群聊',  '好友',  '朋友圈'],
      success: function(res)  {
        console.log(res.tapIndex)
      },
      fail: function(res)  {
        console.log(res.errMsg)
      }
    })   
  },
  /**
   * 页面的初始数据
   */
  data: {
    canIUse: wx.canIUse('button.open-type.getUserInfo'),
    statusBarHeight: getApp().globalData.statusBarHeight,
    coins:'',
    page: 0,
    pageSize: 5,
    totalCount: 0,
    openid: '',
    topics: {}
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    wx.showLoading({
      title: '加载余额',
      mask: true,
    })
    var that = this;
    wx.cloud.callFunction({
      name: 'login',
      complete: res => {
        console.log('个人页面云函数获取到的openid: ', res.result.openid)
        that.setData({
          openid: res.result.openid
        })
        that.getData(that.data.page)
        wx.cloud.callFunction({
          // 云函数名称      
          name: 'count',
          // 传给云函数的参数      
          data: {
            oi: that.data.openid
          },
          success: function (res) {
            console.log('成功调用云函数' + res.result.total)
            var ct = res.result.total
            if (ct > 0) {
              const db2 = wx.cloud.database();
              db2.collection('userscoin')
                .where({
                  _openid: that.data.openid
                })
                .limit(1)
                .get({
                  success: function (res) {
                    console.log("已有" + res.data[0].coin)
                    that.setData({
                      coins: res.data[0].coin
                    })
                    wx.hideLoading()
                  }
                })
              
            }
            else {
              const db2 = wx.cloud.database();
              db2.collection('userscoin').add({
                data: { coin: 10},
                succes:res=>{
                  wx.hideLoading()
                }
              }),
              that.setData({
                  coins: 4
              })
              console.log("新建user")
              
            }
          },
          fail: console.error
        })
      }
    })
    
  },

  /**
   * 获取列表数据
   * 
   */
  getData: function (page) {
    var that = this;
    console.log("page--->" + page);
    const db = wx.cloud.database();
    // 获取总数
    db.collection('cm').where({
      replyid: that.data.openid,
      read: false
    }).count({
      success: function (res) {
        that.data.totalCount = res.total;
      }
    })
    // 获取前十条
    try {
      db.collection('cm')
        .where({
          replyid: that.data.openid,
          read: false
        })
        .limit(that.data.pageSize) // 限制返回数量为 10 条
        .orderBy('date', 'desc')
        .get({
          success: function (res) {
            // res.data 是包含以上定义的两条记录的数组
            // console.log(res.data)
            for (var a = 0; a < res.data.length; a++) {
              var date = res.data[a].date;
              res.data[a].date = date.getFullYear() + '-' + (date.getMonth() + 1) + '-' + date.getDate() + "  " + date.getHours() + ':' + date.getMinutes() + ':' + date.getSeconds();
            }
            that.data.topics = res.data;
            that.setData({
              topics: that.data.topics,
            })
            wx.hideNavigationBarLoading();//隐藏加载
            wx.stopPullDownRefresh();

          },
          fail: function (event) {
            wx.hideNavigationBarLoading();//隐藏加载
            wx.stopPullDownRefresh();
          }
        })
    } catch (e) {
      wx.hideNavigationBarLoading();//隐藏加载
      wx.stopPullDownRefresh();
      console.error(e);
    }
  },
  /**
   * item 点击
   */
  onItemClick: function (event) {
    var topicid = event.currentTarget.dataset.topicid;
    var id = event.currentTarget.dataset.id;
    console.log(topicid);
    wx.navigateTo({
      url: "../homeDetail/homeDetail?id=" + topicid
    })
    wx.cloud.callFunction({
      name: 'read',
      data: {
        id:id
      },
      complete: res => {
        console.log("已读消息")}
    })
  },
  /**
   * 收藏列表
   */
  onCollectClick:function(event){
    wx.navigateTo({
      url: '../collect/collect',
    })
  },
  /**
   * 发布历史
   */
  onHistoryClick:function(event){
    wx.navigateTo({
      url: '../history/history',
    })
  },

  /**
   * 提交意见
   */
  onAdvanceClick:function(event){
    wx.navigateTo({
      url: '../advance/advance',
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    this.getData(this.data.page)
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  clickInvitivation: function(event) {
    this.actioncnt();
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function(event) {
    console.log(event);
  }
})