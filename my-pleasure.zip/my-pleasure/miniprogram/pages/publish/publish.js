// miniprogram/pages/publish/publish.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    statusBarHeight: getApp().globalData.statusBarHeight,
    canIUse: wx.canIUse('button.open-type.getUserInfo'),
    content: '',
    images: [],
    cImg:[],
    submitid:'',
    user: {},
    commentnum:0,
    isLike: false,
    activename:'',
    category: [{
      name: "助力",
      type: "category"
    }, {
      name: "捞人",
      type: "category"
    }, {
      name: "脑洞",
      type: "category"
    }, {
      name: "外快",
      type: "category"
    }, {
      name: "曝光",
      type: "category"
    }],
  },
  switchCategory: function (t) {
    var a = this, e = t.target.dataset, o = e.name;
    this.setData({activename: o });
   
  },
  /**
   * 获取填写的内容
   */
  getTextAreaContent: function(event) {
    this.data.content = event.detail.value;
  },
  /**
   * 选择图片
   */
  chooseImage: function(event) {
    var that = this;
    wx.chooseImage({
      count: 6,
      success: function(res) {
        // tempFilePath可以作为img标签的src属性显示图片
        const tempFilePaths = res.tempFilePaths

        for (var i in tempFilePaths) {
          that.data.images = that.data.images.concat(tempFilePaths[i])
        }
        // 设置图片
        that.setData({
          images: that.data.images,
        })
      },
    })
  },
  /**
   * 发布
   */
  formSubmit: function (e) {
    var that=this
    if (this.data.canIUse) {
      wx.cloud.callFunction({
        name: 'login',
        complete: res => {
          var oi = res.result.openid
          var coin = 0
          const db2 = wx.cloud.database();
          db2.collection('userscoin')
                  .where({
                    _openid: oi
                  })
                  .limit(1)
                  .get({
                    success: function (res) {
                      coin = res.data[0].coin
                      if (coin <= 0) {
                        wx.showModal({
                          title: '余额不足',
                          content: '可前往个人主页查看余额，评论可以增加余额',
                          confirmText: '个人主页',
                          cancelText: '取消发布',
                          success: function (sm) {
                            if (sm.confirm) {
                              wx.reLaunch({
                                url: '../me/me',
                              })
                            } else if (sm.cancel) {
                              console.log('用户点击取消')
                            }
                          }
                        })
                      }
                      else{
                        wx.showLoading({
                          title: '发布中',
                          mask: true,
                        })
                        that.formSubmit2(e)
                      }
                    }
                  })
          }
        }
      )
    }
    else{
      this.jugdeUserLogin();
    }
  },
  formSubmit2: function(e) {
    var that=this
    this.data.content = e.detail.value['input-content'];//form发生了submit事件，携带数据为：', e.detail.value['input-content'
    console.log("内容--->" + this.data.content.trim());
    if (this.data.canIUse) {
      this.jugdeUserLogin();
      this.countcoin();
      if (this.data.images.length > 0) {
        wx.showLoading({
          title: '上传图片中',
          mask: true,
        })
        const name = Math.random() * 1000000;
        const cloudPath = [];
        const cImg = [];
        this.data.images.forEach((item, i) => { cloudPath.push(name + '_' + i + this.data.images[i].match(/\.[^.]+?$/)[0]) })
        let count = 0
        this.data.images.forEach((item, i) => {
          wx.cloud.uploadFile({
            cloudPath: cloudPath[i],//云存储图片名字          
            filePath: this.data.images[i],//临时路径          
            success: res => {
              console.log('[上传图片] 成功：', res)
              console.log("路径" + res.fileID)
              cImg.push(res.fileID)
              count++;
              //云存储图片路径          
            },
            fail: res => { },

            complete: () => {
              console.log("序号" + count)
              if (count == this.data.images.length) {
                this.setData({
                  cImg: cImg
                })
                wx.hideLoading
                console.log("临时" + cImg)
                console.log("最终" + this.data.cImg)
                this.saveDataToServer();
              }
            }
          });
        })
        
      } else if (this.data.content.trim() != '') {
        this.saveDataToServer();
      } else {
        wx.showToast({
          title: '写点什么吧~',
        })
      }

    } else {
      this.jugdeUserLogin();
    }
      
},
  /**
   * 保存到发布集合中
   */
  saveDataToServer: function(event) {
    var that = this;
    const db = wx.cloud.database();
    const topic = db.collection('topic')
    db.collection('topic').add({
      // data 字段表示需新增的 JSON 数据
      data: {
        content: that.data.content,
        date: new Date(),
        activename:that.data.activename,
        images: that.data.cImg,
        user: that.data.user,
        commentnum: that.data.commentnum,
        isLike: that.data.isLike,
        viewnum:0
      },
      success: function(res) {
        // res 是一个对象，其中有 _id 字段标记刚创建的记录的 id
        // 清空，然后重定向到首页
        console.log("success---->" + res)
        
        // 清空数据
        that.data.content = "";
        that.data.cImg = [];
        that.data.activename ="";

        that.setData({
          textContent: '',
          cImg: [],
          activename:'',
        })
        
        that.showTipAndSwitchTab();

      },
      complete: function(res) {
        console.log("complete---->" + res);
      }
    })
  },
  /**
   * 添加成功添加提示，切换页面
   */
  showTipAndSwitchTab: function(event) {
    wx.hideLoading
    wx.showToast({
      title: '金币-1',
    })
    setTimeout(function () {
      //要延时执行的代码
      wx.reLaunch({
        url: '../home/home',
      })
    }, 2000) //延迟时间
    
    console.log("============")
  },
  /**
   * 删除图片
   */
  removeImg: function(event) {
    var position = event.currentTarget.dataset.index;
    this.data.images.splice(position, 1);
    // 渲染图片
    this.setData({
      images: this.data.images,
    })
  },
  // 预览图片
  previewImg: function(e) {
    //获取当前图片的下标
    var index = e.currentTarget.dataset.index;

    wx.previewImage({
      //当前显示图片
      current: this.data.images[index],
      //所有图片
      urls: this.data.images
    })
  },

  /**
   * 计算金额
   */
  countcoin: function () {

    var that = this;
    wx.cloud.callFunction({
      name: 'login',
      complete: res => {
        console.log('云函数获取到的openid: ', res.result.openid)
        var oi = res.result.openid
        var coin = 0
        wx.cloud.callFunction({
          // 云函数名称      
          name: 'count',
          // 传给云函数的参数      
          data: {
            oi: oi
          },
          success: function (res) {
            console.log('成功调用云函数' + res.result.total)
            var ct = res.result.total
            if (ct > 0) {
              const db2 = wx.cloud.database();
              db2.collection('userscoin')
                .where({
                  _openid: oi
                })
                .limit(1)
                .get({
                  success: function (res) {
                    coin = res.data[0].coin
                    console.log("已有" + res.data[0].coin)
                    wx.cloud.callFunction({
                      // 云函数名称      
                      name: 'fixcoin',
                      // 传给云函数的参数      
                      data: {
                        oi: oi,
                        coin: coin,
                        c: -1
                      },
                      success: function (res) {
                        console.log("传入" + oi + coin)
                      }
                    })
                  }
                })
              console.log('修改')
            }
            else {
              const db2 = wx.cloud.database();
              db2.collection('userscoin').add({
                data: { coin: 10 - 1 },

              }),
                console.log("新建user")
            }
          },
          fail: console.error
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    this.jugdeUserLogin();
  },
  /**
   * 判断用户是否登录
   */
  jugdeUserLogin: function(event) {
    var that = this;
    // 查看是否授权
    wx.getSetting({
      success(res) {
        if (res.authSetting['scope.userInfo']) {
          // 已经授权，可以直接调用 getUserInfo 获取头像昵称
          wx.getUserInfo({
            success: function(res) {

              that.data.user = res.userInfo;
              console.log(that.data.user)
            }
          })
        }
      }
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})