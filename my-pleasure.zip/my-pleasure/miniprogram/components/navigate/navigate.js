// pages/components/navigate/navigate.js
const App = getApp();

Component({
  options: {
    addGlobalClass: true,
    
  },
  /**
   * 组件的属性列表
   */
  properties: {
 
  },

  /**
   * 组件的初始数据
   */
  data: {
    openid: '',
    notifyCount: 0
  },
  
  lifetimes: {
    attached: function () {
      this.setData({
        navH: App.globalData.statusBarHeight
      })
      
  
    }
  },
  pageLifetimes: {
    // 组件所在页面的生命周期函数
    
    show: function () { 
      var that=this;
      this.getOpenid();
      },
  },
  /**
   * 组件的方法列表
   */
  
  methods: {
    getOpenid() {
      let that = this;
      wx.cloud.callFunction({
        name: 'login',
        complete: res => {
          console.log('云函数获取到的openid: ', res.result.openid)
          const db = wx.cloud.database();
          db.collection('cm')
            .where({
              replyid: res.result.openid,
              read: false
            }).count({
              success: function (res) {
                that.setData({
                  notifyCount:res.total
                })
               
              }
            })
          console.log("组件显示")
          
          
        }
      })
    },
    clicktome: function () {
      wx.navigateTo({
        url: "../../pages/me/me"
      })
    },
    search: function(e){
      this.triggerEvent('getsearchValue', e.detail.value);
    }
  }
})