// components/back/back.js
const App = getApp();
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    title: String
  },

  /**
   * 组件的初始数据
   */
  data: {

  },
  lifetimes: {
    attached: function () {
      this.setData({
        navH: App.globalData.statusBarHeight
      })
    }
  },
  /**
   * 组件的方法列表
   */
  methods: {
    goBack: function () {
      wx.navigateBack();
    },
  }
})
